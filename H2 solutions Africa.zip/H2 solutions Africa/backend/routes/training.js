/**
 * Training program routes for staff development and certifications
 * Continuous learning module with mock course data
 */
const express = require('express');
const router = express.Router();

// ==================== MOCK TRAINING COURSE DATA ====================
// Sample training courses for IT consulting staff development
// Each course includes: title, technology focus, completion status
const MOCK_COURSES = [
  {
    id: 1,
    courseTitle: 'AWS Cloud Practitioner Certification',
    technologyFocus: 'Cloud Computing',
    completionStatus: 'Completed',
  },
  {
    id: 2,
    courseTitle: 'Azure DevOps Fundamentals',
    technologyFocus: 'DevOps',
    completionStatus: 'In Progress',
  },
  {
    id: 3,
    courseTitle: 'Kubernetes Administration',
    technologyFocus: 'Container Orchestration',
    completionStatus: 'Not Started',
  },
  {
    id: 4,
    courseTitle: 'Python for Data Engineering',
    technologyFocus: 'Data Engineering',
    completionStatus: 'Completed',
  },
  {
    id: 5,
    courseTitle: 'Cybersecurity Essentials',
    technologyFocus: 'Security',
    completionStatus: 'In Progress',
  },
  {
    id: 6,
    courseTitle: 'Agile Project Management',
    technologyFocus: 'Project Management',
    completionStatus: 'Completed',
  },
];

// ==================== ROUTES ====================

/**
 * GET /api/training
 * Fetches all available training courses
 * Returns array of courses with technology focus and completion status
 */
router.get('/', (req, res) => {
  // Return all mock courses with a success wrapper
  res.json({
    success: true,
    count: MOCK_COURSES.length,
    courses: MOCK_COURSES,
  });
});

module.exports = router;
