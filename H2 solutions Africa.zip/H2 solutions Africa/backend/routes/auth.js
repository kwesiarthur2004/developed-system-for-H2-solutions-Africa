/**
 * Authentication routes for user login, logout, and session management
 * Uses mock data - no database required
 */
const express = require('express');
const router = express.Router();

// ==================== MOCK USER DATA ====================
// In-memory mock users with roles: Consultant, Manager, Client
// Format: { email, password, role }
const MOCK_USERS = [
  { email: 'consultant@h2solutions.com', password: 'consultant123', role: 'Consultant' },
  { email: 'manager@h2solutions.com', password: 'manager123', role: 'Manager' },
  { email: 'client@h2solutions.com', password: 'client123', role: 'Client' },
];

// ==================== ROUTES ====================

// GET /api/auth - Health check for auth routes
router.get('/', (req, res) => {
  res.json({ message: 'Auth routes active' });
});

/**
 * POST /api/auth/login
 * Accepts email and password, validates credentials against mock data
 * Returns success message and user role on valid login
 */
router.post('/login', (req, res) => {
  // Extract email and password from request body (expects JSON)
  const { email, password } = req.body;

  // Validate that both fields were provided
  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required',
    });
  }

  // Find a mock user matching the provided credentials
  const user = MOCK_USERS.find(
    (u) => u.email === email && u.password === password
  );

  // If no match found, credentials are invalid
  if (!user) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password',
    });
  }

  // Credentials valid - return success with user role
  res.json({
    success: true,
    message: 'Login successful',
    role: user.role,
    email: user.email,
  });
});

module.exports = router;
