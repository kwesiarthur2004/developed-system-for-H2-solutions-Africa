/**
 * Vendor management routes for IT consulting partners and suppliers
 * Vendor collaboration module with mock data
 */
const express = require('express');
const router = express.Router();

// ==================== MOCK VENDOR DATA ====================
// Sample technology vendors for IT consulting partnerships
// Each vendor includes: name, technologies offered, budget category
const MOCK_VENDORS = [
  {
    id: 1,
    vendorName: 'CloudTech Solutions',
    technologiesOffered: ['AWS', 'Azure', 'Google Cloud'],
    budgetCategory: 'Enterprise',
  },
  {
    id: 2,
    vendorName: 'DevOps Pro Services',
    technologiesOffered: ['Docker', 'Kubernetes', 'Jenkins', 'Terraform'],
    budgetCategory: 'Mid-Range',
  },
  {
    id: 3,
    vendorName: 'SecureNet Systems',
    technologiesOffered: ['Firewall Solutions', 'SIEM', 'Endpoint Protection'],
    budgetCategory: 'Enterprise',
  },
  {
    id: 4,
    vendorName: 'DataFlow Analytics',
    technologiesOffered: ['Power BI', 'Tableau', 'Apache Spark'],
    budgetCategory: 'Mid-Range',
  },
  {
    id: 5,
    vendorName: 'AgileWorks Consulting',
    technologiesOffered: ['Jira', 'Confluence', 'Scrum Training'],
    budgetCategory: 'Budget-Friendly',
  },
  {
    id: 6,
    vendorName: 'AI Innovations Ltd.',
    technologiesOffered: ['Machine Learning', 'NLP', 'Computer Vision'],
    budgetCategory: 'Enterprise',
  },
];

// ==================== ROUTES ====================

/**
 * GET /api/vendors
 * Fetches all vendor partners
 * Returns array of vendors with technologies and budget info
 */
router.get('/', (req, res) => {
  // Return all mock vendors with a success wrapper
  res.json({
    success: true,
    count: MOCK_VENDORS.length,
    vendors: MOCK_VENDORS,
  });
});

module.exports = router;
