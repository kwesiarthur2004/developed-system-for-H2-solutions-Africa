/**
 * Project management routes for digital transformation initiatives
 * Uses mock data - no database required
 */
const express = require('express');
const router = express.Router();

// ==================== MOCK PROJECT DATA ====================
// Sample digital transformation projects with cloud migration tracking
// Each project includes: name, client, migration stage, compatibility status
const MOCK_PROJECTS = [
  {
    id: 1,
    projectName: 'ERP Cloud Migration',
    clientName: 'Acme Corporation',
    cloudMigrationStage: 'In Progress',
    compatibilityStatus: 'Compatible',
  },
  {
    id: 2,
    projectName: 'Legacy System Modernization',
    clientName: 'TechStart Inc.',
    cloudMigrationStage: 'Planning',
    compatibilityStatus: 'Requires Updates',
  },
  {
    id: 3,
    projectName: 'Data Center Consolidation',
    clientName: 'Global Finance Ltd.',
    cloudMigrationStage: 'Completed',
    compatibilityStatus: 'Compatible',
  },
  {
    id: 4,
    projectName: 'CRM Platform Integration',
    clientName: 'Retail Solutions Co.',
    cloudMigrationStage: 'Testing',
    compatibilityStatus: 'Compatible',
  },
  {
    id: 5,
    projectName: 'Infrastructure Automation',
    clientName: 'HealthCare Plus',
    cloudMigrationStage: 'Not Started',
    compatibilityStatus: 'Under Review',
  },
];

// ==================== ROUTES ====================

/**
 * GET /api/projects
 * Fetches all digital transformation projects
 * Returns array of projects with migration and compatibility info
 */
router.get('/', (req, res) => {
  // Return all mock projects with a success wrapper
  res.json({
    success: true,
    count: MOCK_PROJECTS.length,
    projects: MOCK_PROJECTS,
  });
});

module.exports = router;
