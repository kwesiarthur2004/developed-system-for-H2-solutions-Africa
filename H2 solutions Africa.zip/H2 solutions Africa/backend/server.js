/**
 * Digital Transformation Management Platform - Backend Server
 * Node.js Express server for IT consulting department
 */

const express = require('express');
const cors = require('cors');
const path = require('path');

// Import route modules
const authRoutes = require('./routes/auth');
const projectsRoutes = require('./routes/projects');
const trainingRoutes = require('./routes/training');
const vendorsRoutes = require('./routes/vendors');

// Initialize Express application
const app = express();
const PORT = 3000;

// ==================== MIDDLEWARE ====================

// Enable CORS - allows frontend (different origin) to communicate with this API
app.use(cors());

// Parse JSON request bodies - required for handling POST/PUT requests with JSON data
app.use(express.json());

// ==================== ROUTES ====================

// Root route - returns confirmation that the server is running
app.get('/', (req, res) => {
  res.json({
    message: 'Digital Transformation Management Platform API is running',
    status: 'active',
    version: '1.0.0',
  });
});

// Mount route modules - each handles a specific domain
app.use('/api/auth', authRoutes);
app.use('/api/projects', projectsRoutes);
app.use('/api/training', trainingRoutes);
app.use('/api/vendors', vendorsRoutes);
// Also expose at root paths for frontend (http://localhost:3000/projects etc.)
app.use('/projects', projectsRoutes);
app.use('/training', trainingRoutes);
app.use('/vendors', vendorsRoutes);

// Serve frontend (HTML, CSS, JS, images) so logo and pages load from one server
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// ==================== SERVER STARTUP ====================

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
