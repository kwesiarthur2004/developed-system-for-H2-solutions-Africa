/**
 * Digital Transformation Management Platform — Frontend API Connection
 * Connects the frontend to the backend APIs: projects, training, vendors.
 * Fetches data, dynamically updates HTML, and handles errors.
 */

/* ==========================================================================
   NAV: Login / Logout (runs on every page)
   Shows "Logout" after login; clicking Logout clears session and goes home.
   ========================================================================== */
(function () {
  var navAuth = document.getElementById('nav-auth');
  if (!navAuth) return;

  function isLoggedIn() {
    try { return sessionStorage.getItem('loggedIn') === 'true'; } catch (e) { return false; }
  }

  if (isLoggedIn()) {
    navAuth.textContent = 'Logout';
    navAuth.href = 'index.html';
    navAuth.addEventListener('click', function (e) {
      e.preventDefault();
      try { sessionStorage.removeItem('loggedIn'); } catch (err) {}
      window.location.href = 'index.html';
    });
  } else {
    navAuth.textContent = 'Login';
    navAuth.href = 'login.html';
  }
})();

/* ==========================================================================
   API CONFIGURATION
   Frontend connects to backend at http://localhost:3000.
   - Projects:  http://localhost:3000/projects  (or /api/projects if needed)
   - Training:  http://localhost:3000/training
   - Vendors:   http://localhost:3000/vendors
   ========================================================================== */
var API_BASE = 'http://localhost:3000';
var API_ENDPOINTS = {
  projects: API_BASE + '/projects',
  training: API_BASE + '/training',
  vendors: API_BASE + '/vendors',
  authLogin: API_BASE + '/api/auth/login',
};

/* ==========================================================================
   SHARED UTILITIES
   Used across dashboard, training, and vendor pages for safe HTML and errors.
   ========================================================================== */

/**
 * Escape text for safe insertion into HTML (prevents XSS).
 * @param {string} text - Raw text
 * @returns {string} Safe HTML string
 */
function escapeHtml(text) {
  if (text == null) return '';
  var div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Show a user-friendly error when fetch fails (network or server error).
 * @param {HTMLElement} container - Element to update
 * @param {string} message - Error message to display
 * @param {string} errorClass - CSS class for error styling (e.g. 'dashboard-error')
 */
function showFetchError(container, message, errorClass) {
  if (!container) return;
  var defaultMsg = 'Unable to load data. Ensure the backend is running at ' + API_BASE + '.';
  container.innerHTML = '<p class="' + (errorClass || 'dashboard-error') + '">' + escapeHtml(message || defaultMsg) + '</p>';
}

/* ==========================================================================
   PROJECTS API — Fetch and render project data
   ========================================================================== */

/**
 * Fetch project data from the backend and update the given container.
 * @param {string} url - Full API URL (e.g. API_ENDPOINTS.projects)
 * @param {HTMLElement} container - Element to fill with project list HTML
 */
function fetchProjects(url, container) {
  if (!container) return;
  fetch(url)
    .then(function (res) {
      if (!res.ok) throw new Error('Server returned ' + res.status);
      return res.json();
    })
    .then(function (data) {
      if (!data.projects || !data.projects.length) {
        container.innerHTML = '<p class="dashboard-error">No projects to display.</p>';
        return;
      }
      var html = '<ul class="dashboard-list">';
      data.projects.forEach(function (p) {
        html += '<li><strong>' + escapeHtml(p.projectName) + '</strong>';
        html += '<span class="meta">' + escapeHtml(p.clientName) + ' · ';
        html += escapeHtml(p.cloudMigrationStage) + ' · ';
        html += escapeHtml(p.compatibilityStatus || '') + '</span></li>';
      });
      html += '</ul>';
      container.innerHTML = html;
    })
    .catch(function (err) {
      showFetchError(container, err.message || 'Failed to load projects.', 'dashboard-error');
    });
}

/* ==========================================================================
   TRAINING API — Fetch and render training/course data
   ========================================================================== */

/**
 * Fetch training data from the backend and update the given container.
 * @param {string} url - Full API URL (e.g. API_ENDPOINTS.training)
 * @param {HTMLElement} container - Element to fill with course list HTML
 */
function fetchTraining(url, container) {
  if (!container) return;
  fetch(url)
    .then(function (res) {
      if (!res.ok) throw new Error('Server returned ' + res.status);
      return res.json();
    })
    .then(function (data) {
      if (!data.courses || !data.courses.length) {
        container.innerHTML = '<p class="dashboard-error">No training courses to display.</p>';
        return;
      }
      var html = '<ul class="dashboard-list">';
      data.courses.forEach(function (c) {
        html += '<li><strong>' + escapeHtml(c.courseTitle) + '</strong>';
        html += '<span class="meta">' + escapeHtml(c.technologyFocus) + ' · ';
        html += escapeHtml(c.completionStatus || '') + '</span></li>';
      });
      html += '</ul>';
      container.innerHTML = html;
    })
    .catch(function (err) {
      showFetchError(container, err.message || 'Failed to load training.', 'dashboard-error');
    });
}

/**
 * Fetch training data and render on the dedicated training page (with status badges).
 * Uses #training-courses-container and training-course-item markup.
 */
function fetchTrainingPage(url, container) {
  if (!container) return;

  function statusClass(status) {
    if (status === 'Completed') return 'status-completed';
    if (status === 'In Progress') return 'status-in-progress';
    return 'status-not-started';
  }

  fetch(url)
    .then(function (res) {
      if (!res.ok) throw new Error('Server returned ' + res.status);
      return res.json();
    })
    .then(function (data) {
      if (!data.courses || !data.courses.length) {
        container.innerHTML = '<p class="training-error">No training courses to display.</p>';
        return;
      }
      var html = '<ul class="training-course-list">';
      data.courses.forEach(function (c) {
        html += '<li class="training-course-item">';
        html += '<span class="course-title">' + escapeHtml(c.courseTitle) + '</span>';
        html += '<span class="completion-status ' + statusClass(c.completionStatus) + '">' + escapeHtml(c.completionStatus || '') + '</span>';
        html += '<span class="course-meta">' + escapeHtml(c.technologyFocus) + '</span>';
        html += '</li>';
      });
      html += '</ul>';
      container.innerHTML = html;
    })
    .catch(function (err) {
      showFetchError(container, err.message || 'Unable to load courses.', 'training-error');
    });
}

/* ==========================================================================
   VENDORS API — Fetch and render vendor data
   ========================================================================== */

/**
 * Fetch vendor data from the backend and update the given container.
 * @param {string} url - Full API URL (e.g. API_ENDPOINTS.vendors)
 * @param {HTMLElement} container - Element to fill with vendor cards HTML
 */
function fetchVendors(url, container) {
  if (!container) return;
  fetch(url)
    .then(function (res) {
      if (!res.ok) throw new Error('Server returned ' + res.status);
      return res.json();
    })
    .then(function (data) {
      if (!data.vendors || !data.vendors.length) {
        container.innerHTML = '<p class="vendors-error">No vendors to display.</p>';
        return;
      }
      var html = '<ul class="vendors-grid">';
      data.vendors.forEach(function (v) {
        var techList = Array.isArray(v.technologiesOffered)
          ? v.technologiesOffered.join(', ')
          : String(v.technologiesOffered || '');
        html += '<li class="vendor-card">';
        html += '<h3 class="vendor-name">' + escapeHtml(v.vendorName) + '</h3>';
        html += '<p class="vendor-technologies"><strong>Technologies</strong> ' + escapeHtml(techList) + '</p>';
        html += '<p class="vendor-budget"><strong>Budget:</strong> ' + escapeHtml(v.budgetCategory || '') + '</p>';
        html += '</li>';
      });
      html += '</ul>';
      container.innerHTML = html;
    })
    .catch(function (err) {
      showFetchError(container, err.message || 'Unable to load vendors.', 'vendors-error');
    });
}

/* ==========================================================================
   DASHBOARD PAGE — Load projects, training, and vendors into placeholders
   ========================================================================== */
(function () {
  var projectsEl = document.getElementById('projects-container');
  var trainingEl = document.getElementById('training-container');
  var vendorsEl = document.getElementById('vendors-container');

  if (!projectsEl && !trainingEl && !vendorsEl) return;

  if (projectsEl) fetchProjects(API_ENDPOINTS.projects, projectsEl);
  if (trainingEl) fetchTraining(API_ENDPOINTS.training, trainingEl);
  if (vendorsEl) fetchVendors(API_ENDPOINTS.vendors, vendorsEl);
})();

/* ==========================================================================
   TRAINING PAGE — Load courses with completion status into #training-courses-container
   ========================================================================== */
(function () {
  var container = document.getElementById('training-courses-container');
  if (container) fetchTrainingPage(API_ENDPOINTS.training, container);
})();

/* ==========================================================================
   VENDORS PAGE — Load vendor cards into #vendors-cards-container
   ========================================================================== */
(function () {
  var container = document.getElementById('vendors-cards-container');
  if (container) fetchVendors(API_ENDPOINTS.vendors, container);
})();

/* ==========================================================================
   LOGIN PAGE — Auth API; submit credentials and show feedback
   ========================================================================== */
(function () {
  var form = document.getElementById('login-form');
  var feedbackEl = document.getElementById('login-feedback');
  var loginBtn = document.getElementById('login-btn');

  function showFeedback(message, type) {
    if (!feedbackEl) return;
    feedbackEl.textContent = message;
    feedbackEl.className = 'feedback ' + (type === 'success' ? 'success' : 'error');
  }

  function clearFeedback() {
    if (feedbackEl) {
      feedbackEl.textContent = '';
      feedbackEl.className = 'feedback';
    }
  }

  function setLoading(loading) {
    if (loginBtn) {
      loginBtn.disabled = loading;
      loginBtn.textContent = loading ? 'Signing in…' : 'Login';
    }
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFeedback();

      var email = (document.getElementById('email') && document.getElementById('email').value) ? document.getElementById('email').value.trim() : '';
      var password = (document.getElementById('password') && document.getElementById('password').value) ? document.getElementById('password').value : '';

      if (!email || !password) {
        showFeedback('Please enter both email and password.', 'error');
        return;
      }

      setLoading(true);

      fetch(API_ENDPOINTS.authLogin, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email, password: password }),
      })
        .then(function (res) {
          return res.json().then(function (data) {
            return { ok: res.ok, data: data };
          });
        })
        .then(function (result) {
          if (result.ok) {
            // Mark user as logged in so nav shows "Logout" on all pages
            try { sessionStorage.setItem('loggedIn', 'true'); } catch (e) {}
            showFeedback('Login successful. Role: ' + (result.data.role || '') + '. Redirecting...', 'success');
            // Redirect to dashboard after 1 second
            setTimeout(function () {
              window.location.href = 'dashboard.html';
            }, 1000);
          } else {
            showFeedback(result.data.message || 'Login failed. Please check your credentials.', 'error');
          }
        })
        .catch(function () {
          showFeedback('Unable to reach the server. Ensure the backend is running at ' + API_BASE + '.', 'error');
        })
        .finally(function () {
          setLoading(false);
        });
    });
  }
})();
